==============================================
VAULT CLASH APP - GITHUB SETUP (2 MINUTES)
==============================================

Bas ye 2 files apne GitHub Repository me upload karein:
1. index.html
2. manifest.json

Steps:
1. GitHub.com par 'New repository' banayein (naam: vault-clash).
2. 'uploading an existing file' par click karke index.html aur manifest.json dono upload karein.
3. Settings -> Pages me jayein, Branch 'main' select karein aur Save karein!
4. 1 minute me aapka live link activate ho jayega:
   https://<aapka-username>.github.io/vault-clash/

App Kaise Banayein:
- Mobile Chrome me link kholein -> 3 dots dabayein -> 'Install app' par tap karein!
- Ya PWABuilder.com par link daal kar direct Android APK download karein!
